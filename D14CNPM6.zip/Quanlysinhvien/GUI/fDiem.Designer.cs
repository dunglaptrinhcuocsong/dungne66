﻿namespace Quanlysinhvien.GUI
{
    partial class fDiem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fDiem));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.MaSV = new System.Windows.Forms.Label();
            this.btnTim = new DevExpress.XtraEditors.SimpleButton();
            this.txtMaSV = new DevExpress.XtraEditors.TextEdit();
            this.txtMaLHP = new DevExpress.XtraEditors.TextEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.txtGhiChu = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtMaMonHoc = new DevExpress.XtraEditors.TextEdit();
            this.txtDuThi2 = new DevExpress.XtraEditors.TextEdit();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLuu = new DevExpress.XtraEditors.SimpleButton();
            this.label13 = new System.Windows.Forms.Label();
            this.txtXepLoai = new DevExpress.XtraEditors.TextEdit();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDiemThi2 = new DevExpress.XtraEditors.TextEdit();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDiemThi1 = new DevExpress.XtraEditors.TextEdit();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTK = new DevExpress.XtraEditors.TextEdit();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTBThuongKy = new DevExpress.XtraEditors.TextEdit();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbDuThi = new DevExpress.XtraEditors.ComboBoxEdit();
            this.label7 = new System.Windows.Forms.Label();
            this.txtThuongXuyen2 = new DevExpress.XtraEditors.TextEdit();
            this.label6 = new System.Windows.Forms.Label();
            this.txtThuongXuyen1 = new DevExpress.XtraEditors.TextEdit();
            this.txtLanHoc = new DevExpress.XtraEditors.TextEdit();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTenSV = new DevExpress.XtraEditors.TextEdit();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaSV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaLHP.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaMonHoc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDuThi2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXepLoai.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemThi2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemThi1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTK.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTBThuongKy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbbDuThi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThuongXuyen2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThuongXuyen1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLanHoc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenSV.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.MaSV);
            this.groupControl1.Controls.Add(this.btnTim);
            this.groupControl1.Controls.Add(this.txtMaSV);
            this.groupControl1.Controls.Add(this.txtMaLHP);
            this.groupControl1.Controls.Add(this.label1);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1096, 191);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Nhập thông tin";
            // 
            // MaSV
            // 
            this.MaSV.AutoSize = true;
            this.MaSV.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.MaSV.Location = new System.Drawing.Point(104, 102);
            this.MaSV.Name = "MaSV";
            this.MaSV.Size = new System.Drawing.Size(56, 21);
            this.MaSV.TabIndex = 5;
            this.MaSV.Text = "Mã SV";
            // 
            // btnTim
            // 
            this.btnTim.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTim.Appearance.Options.UseFont = true;
            this.btnTim.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnTim.ImageOptions.Image")));
            this.btnTim.Location = new System.Drawing.Point(603, 65);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(120, 49);
            this.btnTim.TabIndex = 4;
            this.btnTim.Text = "Tìm";
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // txtMaSV
            // 
            this.txtMaSV.Location = new System.Drawing.Point(247, 99);
            this.txtMaSV.Name = "txtMaSV";
            this.txtMaSV.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMaSV.Properties.Appearance.Options.UseFont = true;
            this.txtMaSV.Size = new System.Drawing.Size(278, 28);
            this.txtMaSV.TabIndex = 3;
            // 
            // txtMaLHP
            // 
            this.txtMaLHP.Location = new System.Drawing.Point(247, 53);
            this.txtMaLHP.Name = "txtMaLHP";
            this.txtMaLHP.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMaLHP.Properties.Appearance.Options.UseFont = true;
            this.txtMaLHP.Size = new System.Drawing.Size(278, 28);
            this.txtMaLHP.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(104, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Lớp Học Phần";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.txtGhiChu);
            this.groupControl2.Controls.Add(this.txtMaMonHoc);
            this.groupControl2.Controls.Add(this.txtDuThi2);
            this.groupControl2.Controls.Add(this.label2);
            this.groupControl2.Controls.Add(this.btnLuu);
            this.groupControl2.Controls.Add(this.label13);
            this.groupControl2.Controls.Add(this.txtXepLoai);
            this.groupControl2.Controls.Add(this.label12);
            this.groupControl2.Controls.Add(this.txtDiemThi2);
            this.groupControl2.Controls.Add(this.label10);
            this.groupControl2.Controls.Add(this.txtDiemThi1);
            this.groupControl2.Controls.Add(this.label11);
            this.groupControl2.Controls.Add(this.txtTK);
            this.groupControl2.Controls.Add(this.label8);
            this.groupControl2.Controls.Add(this.txtTBThuongKy);
            this.groupControl2.Controls.Add(this.label9);
            this.groupControl2.Controls.Add(this.cbbDuThi);
            this.groupControl2.Controls.Add(this.label7);
            this.groupControl2.Controls.Add(this.txtThuongXuyen2);
            this.groupControl2.Controls.Add(this.label6);
            this.groupControl2.Controls.Add(this.txtThuongXuyen1);
            this.groupControl2.Controls.Add(this.txtLanHoc);
            this.groupControl2.Controls.Add(this.label4);
            this.groupControl2.Controls.Add(this.label5);
            this.groupControl2.Controls.Add(this.txtTenSV);
            this.groupControl2.Controls.Add(this.label3);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl2.Location = new System.Drawing.Point(0, 191);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(1096, 402);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "Sửa điểm";
            this.groupControl2.Visible = false;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(734, 333);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtGhiChu.Properties.Appearance.Options.UseFont = true;
            this.txtGhiChu.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGhiChu.Properties.Items.AddRange(new object[] {
            "đang học",
            "đạt",
            "học lại"});
            this.txtGhiChu.Size = new System.Drawing.Size(278, 28);
            this.txtGhiChu.TabIndex = 34;
            // 
            // txtMaMonHoc
            // 
            this.txtMaMonHoc.Location = new System.Drawing.Point(247, 141);
            this.txtMaMonHoc.Name = "txtMaMonHoc";
            this.txtMaMonHoc.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtMaMonHoc.Properties.Appearance.Options.UseFont = true;
            this.txtMaMonHoc.Properties.ReadOnly = true;
            this.txtMaMonHoc.Size = new System.Drawing.Size(278, 28);
            this.txtMaMonHoc.TabIndex = 33;
            // 
            // txtDuThi2
            // 
            this.txtDuThi2.Location = new System.Drawing.Point(734, 52);
            this.txtDuThi2.Name = "txtDuThi2";
            this.txtDuThi2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDuThi2.Properties.Appearance.Options.UseFont = true;
            this.txtDuThi2.Size = new System.Drawing.Size(278, 28);
            this.txtDuThi2.TabIndex = 32;
            this.txtDuThi2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(104, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 21);
            this.label2.TabIndex = 30;
            this.label2.Text = "Môn";
            // 
            // btnLuu
            // 
            this.btnLuu.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnLuu.Appearance.Options.UseFont = true;
            this.btnLuu.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLuu.ImageOptions.Image")));
            this.btnLuu.Location = new System.Drawing.Point(516, 31);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(120, 49);
            this.btnLuu.TabIndex = 29;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label13.Location = new System.Drawing.Point(591, 340);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 21);
            this.label13.TabIndex = 27;
            this.label13.Text = "Ghi chú";
            // 
            // txtXepLoai
            // 
            this.txtXepLoai.Location = new System.Drawing.Point(247, 345);
            this.txtXepLoai.Name = "txtXepLoai";
            this.txtXepLoai.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtXepLoai.Properties.Appearance.Options.UseFont = true;
            this.txtXepLoai.Size = new System.Drawing.Size(278, 28);
            this.txtXepLoai.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label12.Location = new System.Drawing.Point(104, 348);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 21);
            this.label12.TabIndex = 25;
            this.label12.Text = "Xếp loại";
            // 
            // txtDiemThi2
            // 
            this.txtDiemThi2.Location = new System.Drawing.Point(734, 287);
            this.txtDiemThi2.Name = "txtDiemThi2";
            this.txtDiemThi2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDiemThi2.Properties.Appearance.Options.UseFont = true;
            this.txtDiemThi2.Properties.BeepOnError = false;
            this.txtDiemThi2.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtDiemThi2.Properties.MaskSettings.Set("mask", "##.##");
            this.txtDiemThi2.Properties.UseMaskAsDisplayFormat = true;
            this.txtDiemThi2.Size = new System.Drawing.Size(278, 28);
            this.txtDiemThi2.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.Location = new System.Drawing.Point(591, 290);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 21);
            this.label10.TabIndex = 23;
            this.label10.Text = "Điểm thi lần 2";
            // 
            // txtDiemThi1
            // 
            this.txtDiemThi1.Location = new System.Drawing.Point(734, 238);
            this.txtDiemThi1.Name = "txtDiemThi1";
            this.txtDiemThi1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtDiemThi1.Properties.Appearance.Options.UseFont = true;
            this.txtDiemThi1.Properties.BeepOnError = false;
            this.txtDiemThi1.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtDiemThi1.Properties.MaskSettings.Set("mask", "##.##");
            this.txtDiemThi1.Properties.UseMaskAsDisplayFormat = true;
            this.txtDiemThi1.Size = new System.Drawing.Size(278, 28);
            this.txtDiemThi1.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(591, 241);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 21);
            this.label11.TabIndex = 21;
            this.label11.Text = "Điểm thi lần 1";
            // 
            // txtTK
            // 
            this.txtTK.Location = new System.Drawing.Point(247, 291);
            this.txtTK.Name = "txtTK";
            this.txtTK.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTK.Properties.Appearance.Options.UseFont = true;
            this.txtTK.Size = new System.Drawing.Size(278, 28);
            this.txtTK.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(104, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 21);
            this.label8.TabIndex = 19;
            this.label8.Text = "Điểm tổng kết";
            // 
            // txtTBThuongKy
            // 
            this.txtTBThuongKy.Location = new System.Drawing.Point(247, 242);
            this.txtTBThuongKy.Name = "txtTBThuongKy";
            this.txtTBThuongKy.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTBThuongKy.Properties.Appearance.Options.UseFont = true;
            this.txtTBThuongKy.Size = new System.Drawing.Size(278, 28);
            this.txtTBThuongKy.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(104, 245);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 21);
            this.label9.TabIndex = 17;
            this.label9.Text = "TBThuongKy";
            // 
            // cbbDuThi
            // 
            this.cbbDuThi.Location = new System.Drawing.Point(247, 193);
            this.cbbDuThi.Name = "cbbDuThi";
            this.cbbDuThi.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbbDuThi.Properties.Appearance.Options.UseFont = true;
            this.cbbDuThi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbbDuThi.Properties.Items.AddRange(new object[] {
            "Có",
            "Không"});
            this.cbbDuThi.Size = new System.Drawing.Size(278, 28);
            this.cbbDuThi.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(104, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 21);
            this.label7.TabIndex = 14;
            this.label7.Text = "Được dự thi";
            // 
            // txtThuongXuyen2
            // 
            this.txtThuongXuyen2.Location = new System.Drawing.Point(734, 190);
            this.txtThuongXuyen2.Name = "txtThuongXuyen2";
            this.txtThuongXuyen2.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtThuongXuyen2.Properties.Appearance.Options.UseFont = true;
            this.txtThuongXuyen2.Properties.BeepOnError = false;
            this.txtThuongXuyen2.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtThuongXuyen2.Properties.MaskSettings.Set("mask", "##.##");
            this.txtThuongXuyen2.Properties.UseMaskAsDisplayFormat = true;
            this.txtThuongXuyen2.Size = new System.Drawing.Size(278, 28);
            this.txtThuongXuyen2.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(591, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 21);
            this.label6.TabIndex = 12;
            this.label6.Text = "Thường xuyên 2";
            // 
            // txtThuongXuyen1
            // 
            this.txtThuongXuyen1.Location = new System.Drawing.Point(734, 141);
            this.txtThuongXuyen1.Name = "txtThuongXuyen1";
            this.txtThuongXuyen1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtThuongXuyen1.Properties.Appearance.Options.UseFont = true;
            this.txtThuongXuyen1.Properties.BeepOnError = false;
            this.txtThuongXuyen1.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtThuongXuyen1.Properties.MaskSettings.Set("mask", "##.##");
            this.txtThuongXuyen1.Properties.UseMaskAsDisplayFormat = true;
            this.txtThuongXuyen1.Size = new System.Drawing.Size(278, 28);
            this.txtThuongXuyen1.TabIndex = 11;
            // 
            // txtLanHoc
            // 
            this.txtLanHoc.Location = new System.Drawing.Point(734, 95);
            this.txtLanHoc.Name = "txtLanHoc";
            this.txtLanHoc.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtLanHoc.Properties.Appearance.Options.UseFont = true;
            this.txtLanHoc.Size = new System.Drawing.Size(278, 28);
            this.txtLanHoc.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(591, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 21);
            this.label4.TabIndex = 9;
            this.label4.Text = "Thường xuyên 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(591, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "Lần học";
            // 
            // txtTenSV
            // 
            this.txtTenSV.Location = new System.Drawing.Point(247, 95);
            this.txtTenSV.Name = "txtTenSV";
            this.txtTenSV.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtTenSV.Properties.Appearance.Options.UseFont = true;
            this.txtTenSV.Size = new System.Drawing.Size(278, 28);
            this.txtTenSV.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(104, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tên SV";
            // 
            // fDiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.Name = "fDiem";
            this.Size = new System.Drawing.Size(1096, 593);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaSV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaLHP.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGhiChu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaMonHoc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDuThi2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtXepLoai.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemThi2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemThi1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTK.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTBThuongKy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbbDuThi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThuongXuyen2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThuongXuyen1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLanHoc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTenSV.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnTim;
        private DevExpress.XtraEditors.TextEdit txtMaSV;
        private DevExpress.XtraEditors.TextEdit txtMaLHP;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.SimpleButton btnLuu;
        private System.Windows.Forms.Label label13;
        private DevExpress.XtraEditors.TextEdit txtXepLoai;
        private System.Windows.Forms.Label label12;
        private DevExpress.XtraEditors.TextEdit txtDiemThi2;
        private System.Windows.Forms.Label label10;
        private DevExpress.XtraEditors.TextEdit txtDiemThi1;
        private System.Windows.Forms.Label label11;
        private DevExpress.XtraEditors.TextEdit txtTK;
        private System.Windows.Forms.Label label8;
        private DevExpress.XtraEditors.TextEdit txtTBThuongKy;
        private System.Windows.Forms.Label label9;
        private DevExpress.XtraEditors.ComboBoxEdit cbbDuThi;
        private System.Windows.Forms.Label label7;
        private DevExpress.XtraEditors.TextEdit txtThuongXuyen2;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.TextEdit txtThuongXuyen1;
        private DevExpress.XtraEditors.TextEdit txtLanHoc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.TextEdit txtTenSV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label MaSV;
        private DevExpress.XtraEditors.TextEdit txtDuThi2;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.TextEdit txtMaMonHoc;
        private DevExpress.XtraEditors.ComboBoxEdit txtGhiChu;
    }
}
