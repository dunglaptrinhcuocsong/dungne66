﻿namespace Quanlysinhvien.GUI
{
    partial class ucFrmDoiMatKhau
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucFrmDoiMatKhau));
            this.lb_ThanhCong = new DevExpress.XtraEditors.LabelControl();
            this.lb_sai = new DevExpress.XtraEditors.LabelControl();
            this.lb_KhongKhop = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btn_Huy = new DevExpress.XtraEditors.SimpleButton();
            this.btn_CN = new DevExpress.XtraEditors.SimpleButton();
            this.txt_NL = new DevExpress.XtraEditors.TextEdit();
            this.txt_MKM = new DevExpress.XtraEditors.TextEdit();
            this.txt_MKC = new DevExpress.XtraEditors.TextEdit();
            this.lb_Trong = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.txt_NL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MKM.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MKC.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_ThanhCong
            // 
            this.lb_ThanhCong.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ThanhCong.Appearance.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lb_ThanhCong.Appearance.Options.UseFont = true;
            this.lb_ThanhCong.Appearance.Options.UseForeColor = true;
            this.lb_ThanhCong.Location = new System.Drawing.Point(263, 242);
            this.lb_ThanhCong.Margin = new System.Windows.Forms.Padding(4);
            this.lb_ThanhCong.Name = "lb_ThanhCong";
            this.lb_ThanhCong.Size = new System.Drawing.Size(235, 24);
            this.lb_ThanhCong.TabIndex = 17;
            this.lb_ThanhCong.Text = "Đổi mật khẩu thành công!";
            this.lb_ThanhCong.Visible = false;
            // 
            // lb_sai
            // 
            this.lb_sai.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sai.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lb_sai.Appearance.Options.UseFont = true;
            this.lb_sai.Appearance.Options.UseForeColor = true;
            this.lb_sai.Location = new System.Drawing.Point(573, 86);
            this.lb_sai.Margin = new System.Windows.Forms.Padding(4);
            this.lb_sai.Name = "lb_sai";
            this.lb_sai.Size = new System.Drawing.Size(21, 17);
            this.lb_sai.TabIndex = 15;
            this.lb_sai.Text = "Sai";
            this.lb_sai.Visible = false;
            // 
            // lb_KhongKhop
            // 
            this.lb_KhongKhop.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_KhongKhop.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lb_KhongKhop.Appearance.Options.UseFont = true;
            this.lb_KhongKhop.Appearance.Options.UseForeColor = true;
            this.lb_KhongKhop.Location = new System.Drawing.Point(573, 199);
            this.lb_KhongKhop.Margin = new System.Windows.Forms.Padding(4);
            this.lb_KhongKhop.Name = "lb_KhongKhop";
            this.lb_KhongKhop.Size = new System.Drawing.Size(77, 17);
            this.lb_KhongKhop.TabIndex = 16;
            this.lb_KhongKhop.Text = "Không khớp";
            this.lb_KhongKhop.Visible = false;
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(174, 196);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 21);
            this.labelControl3.TabIndex = 9;
            this.labelControl3.Text = "Nhập lại:";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(174, 142);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(106, 21);
            this.labelControl2.TabIndex = 10;
            this.labelControl2.Text = "Mật khẩu mới:";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(174, 82);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(96, 21);
            this.labelControl1.TabIndex = 11;
            this.labelControl1.Text = "Mật khẩu cũ:";
            // 
            // btn_Huy
            // 
            this.btn_Huy.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_Huy.Appearance.Options.UseFont = true;
            this.btn_Huy.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_Huy.ImageOptions.Image")));
            this.btn_Huy.Location = new System.Drawing.Point(417, 284);
            this.btn_Huy.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Huy.Name = "btn_Huy";
            this.btn_Huy.Size = new System.Drawing.Size(129, 44);
            this.btn_Huy.TabIndex = 7;
            this.btn_Huy.Text = "Hủy";
            this.btn_Huy.Click += new System.EventHandler(this.btn_Huy_Click);
            // 
            // btn_CN
            // 
            this.btn_CN.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btn_CN.Appearance.Options.UseFont = true;
            this.btn_CN.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_CN.ImageOptions.Image")));
            this.btn_CN.Location = new System.Drawing.Point(174, 284);
            this.btn_CN.Margin = new System.Windows.Forms.Padding(4);
            this.btn_CN.Name = "btn_CN";
            this.btn_CN.Size = new System.Drawing.Size(143, 44);
            this.btn_CN.TabIndex = 8;
            this.btn_CN.Text = "Chấp Nhận";
            this.btn_CN.Click += new System.EventHandler(this.btn_CN_Click);
            // 
            // txt_NL
            // 
            this.txt_NL.Location = new System.Drawing.Point(302, 192);
            this.txt_NL.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NL.Name = "txt_NL";
            this.txt_NL.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_NL.Properties.Appearance.Options.UseFont = true;
            this.txt_NL.Size = new System.Drawing.Size(244, 28);
            this.txt_NL.TabIndex = 12;
            // 
            // txt_MKM
            // 
            this.txt_MKM.Location = new System.Drawing.Point(302, 135);
            this.txt_MKM.Margin = new System.Windows.Forms.Padding(4);
            this.txt_MKM.Name = "txt_MKM";
            this.txt_MKM.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_MKM.Properties.Appearance.Options.UseFont = true;
            this.txt_MKM.Size = new System.Drawing.Size(244, 28);
            this.txt_MKM.TabIndex = 13;
            // 
            // txt_MKC
            // 
            this.txt_MKC.Location = new System.Drawing.Point(302, 80);
            this.txt_MKC.Margin = new System.Windows.Forms.Padding(4);
            this.txt_MKC.Name = "txt_MKC";
            this.txt_MKC.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txt_MKC.Properties.Appearance.Options.UseFont = true;
            this.txt_MKC.Size = new System.Drawing.Size(244, 28);
            this.txt_MKC.TabIndex = 14;
            // 
            // lb_Trong
            // 
            this.lb_Trong.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Trong.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lb_Trong.Appearance.Options.UseFont = true;
            this.lb_Trong.Appearance.Options.UseForeColor = true;
            this.lb_Trong.Location = new System.Drawing.Point(573, 138);
            this.lb_Trong.Margin = new System.Windows.Forms.Padding(4);
            this.lb_Trong.Name = "lb_Trong";
            this.lb_Trong.Size = new System.Drawing.Size(44, 17);
            this.lb_Trong.TabIndex = 18;
            this.lb_Trong.Text = "Trống!";
            this.lb_Trong.Visible = false;
            // 
            // ucFrmDoiMatKhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lb_Trong);
            this.Controls.Add(this.lb_ThanhCong);
            this.Controls.Add(this.lb_sai);
            this.Controls.Add(this.lb_KhongKhop);
            this.Controls.Add(this.txt_NL);
            this.Controls.Add(this.txt_MKM);
            this.Controls.Add(this.txt_MKC);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btn_Huy);
            this.Controls.Add(this.btn_CN);
            this.Name = "ucFrmDoiMatKhau";
            this.Size = new System.Drawing.Size(726, 528);
            ((System.ComponentModel.ISupportInitialize)(this.txt_NL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MKM.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_MKC.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl lb_ThanhCong;
        private DevExpress.XtraEditors.LabelControl lb_sai;
        private DevExpress.XtraEditors.LabelControl lb_KhongKhop;
        private DevExpress.XtraEditors.TextEdit txt_NL;
        private DevExpress.XtraEditors.TextEdit txt_MKM;
        private DevExpress.XtraEditors.TextEdit txt_MKC;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton btn_Huy;
        private DevExpress.XtraEditors.SimpleButton btn_CN;
        private DevExpress.XtraEditors.LabelControl lb_Trong;
    }
}
