﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quanlysinhvien.DTO
{
    class MonHoc
    {
        public string mamonhoc { get; set; }
        public string tenmonhoc { get; set; }
        public int sotinchi { get; set; }
        public string makhoa { get; set; }
    }
}
