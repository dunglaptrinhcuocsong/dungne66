﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quanlysinhvien.DTO
{
    class LopHoc
    {
        public string malop { get; set; }
        public int magv { get; set; }
        public string tenlop { get; set; }
        public string manganh { get; set; }
        public long namvaotruong { get; set; }
    }
}
