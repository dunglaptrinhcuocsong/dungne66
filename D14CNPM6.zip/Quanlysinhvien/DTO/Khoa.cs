﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quanlysinhvien.DTO
{
    class Khoa
    {
        public string makhoa { get; set; }
        public string tenkhoa { get; set; }
    }
}
