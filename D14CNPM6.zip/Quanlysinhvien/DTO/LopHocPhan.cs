﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quanlysinhvien.DTO
{
    class LopHocPhan
    {
        public string malophocphan { get; set; }
        public string malop { get; set; }
        public string mamonhoc { get; set; }
        public int magv { get; set; }
        public int hocky { get; set; }
        public string namhoc { get; set; }
        public string trangthai { get; set; }
    }
}
